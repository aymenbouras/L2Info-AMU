# Gestion des notes des étudiants

## Description du projet

Le but de ce TP est de créer des classes permettant de représenter des étudiants (classe `Student`), des notes (classe `Grade`), des résultats à une unité d'enseignement (classe `TeachingUnitResult`) et des promotions d'étudiants (classe `Cohort`).

## Membres du projet

- Bouras, Aymen, GROUPE : 01
